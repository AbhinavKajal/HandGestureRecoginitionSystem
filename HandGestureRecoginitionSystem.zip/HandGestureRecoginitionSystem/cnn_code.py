"""
1. CODE USAGE: python cnn_code.py
2. The code assumes the image size to be 64X64. Please ensure the same!
3. The code saves an excel "output.xlsx" with two columns, GT and Pred. 
4. GT is the encoded version of the ground truth and the Pred is the encoded version of prediction
NOTE: Create the dataset as explained in the mail and change the "path_to_dataset" variable accordingly.

"""



############ Give the path of the "datasets" folder here! ###############
path_to_dataset = "datasets/"
#########################################################################

########### Reduce this to get better speed. It may also mean lower accuracy. #######
num_epochs = 30
################################################################################################


import torch
import matplotlib.pyplot as plt
from torchvision import datasets, transforms
from torch import nn, optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
import pandas as pd
from time import time
from sklearn.metrics import accuracy_score, f1_score


transform = transforms.Compose([transforms.ToTensor(),
                              transforms.Normalize((0.5,), (0.5,)),
                              ])

class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 10, 5)
        self.conv2 = nn.Conv2d(10, 16, 3)
        self.fc1 = nn.Linear(16 * 14 * 14, 120)  
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 3)

    def forward(self, x):
        x = F.max_pool2d(F.relu(self.conv1(x)), (2, 2))
        x = F.max_pool2d(F.relu(self.conv2(x)), 2)
        x = x.view(-1, self.num_flat_features(x))
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

    def num_flat_features(self, x):
        size = x.size()[1:]  # all dimensions except the batch dimension
        #print(size)
        num_features = 1
        for s in size:
            num_features = num_features*s
        return num_features

time_start = time()
net = Net()

criterion = nn.CrossEntropyLoss()
optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9)

data_f1 = datasets.ImageFolder(root = path_to_dataset+'train/',transform = transform)
folderL = DataLoader(data_f1,batch_size = 20,shuffle = True)
dataiter = iter(folderL)
images,labels= next(dataiter)

print(labels)

torch.manual_seed(0)
mini_batch = 20
loss_values = []
for epoch in range(num_epochs):   
    for i, data in enumerate(folderL, 0):
        
        inputs, labels = data
        
        
        optimizer.zero_grad()

        
        outputs = net(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        print('[%d, %5d] loss: %.3f' %
              (epoch + 1, i + 1, loss.item()))
        loss_values.append(loss.item())
      
plt.plot(loss_values)
plt.title("Loss vs Iterations curve")

print('Finished Training')

correct = 0
total = 0
with torch.no_grad():
    for data in folderL:
        images, labels = data
        outputs = net(images)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print('Accuracy of the network on the train images: %d %%' % (
    100 * correct / total))


data_f2 = datasets.ImageFolder(root = path_to_dataset+'test/',transform = transform)
folderTest = DataLoader(data_f2,batch_size = 1,shuffle = False)

correct = 0
total = 0
gt_arr = []
pred_arr = []
with torch.no_grad():
    for data in folderTest:
        images, labels = data
        outputs = net(images)
        _, predicted = torch.max(outputs.data, 1)
        gt_arr.append(labels.numpy()[0])
        pred_arr.append(predicted.numpy()[0])


df = pd.DataFrame({
    'GT': gt_arr,
    'Pred': pred_arr
})

excel_filename = 'output.xlsx'
df.to_excel(excel_filename, index=False)
print("Saved the predictions in the Excel. Use it to calculate the accuracy and F1 score!")

print("Total time taken = ",time()-time_start," sec")
df = pd.read_excel('output.xlsx')

accuracy = accuracy_score(df['GT'], df['Pred'])
print(f'Accuracy: {accuracy * 100:.2f}%')

f1 = f1_score(df['GT'], df['Pred'], average='weighted')
print(f'F1 Score: {f1:.2f}')